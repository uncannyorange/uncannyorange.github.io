---
layout: crimson
---
# Paint Bridges
### A logic game, courtesy of Superwibr.
<br/>
