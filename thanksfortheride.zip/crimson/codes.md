---
layout: crimson
---
# CRIMSON codes

<small>[return to console](./home.html)</small>  

- "CR-000" Opens nothing  

- "CR-001" Opens REVOLT+  

- "CR-002" Opens the console  

- "CR-003" Opens the Queen Crimson directives  

- "CR-004" Opens the new DEFIANT store  

- "CR-005" Opens the CRIMSON changelog

