---
layout: crimson
---
# Queen Crimson directives
## I have many names. But since you are in CRIMSON, call me Queen Crimson.
***
### June 23 2020
I finally have created the core of CRIMSON. A few nasty errors along the way, but I managed to stick this together.
<br/>

### June 24 2020
I shall sleep untill there is world to corrupt. The universe is doing my job for the moment.