# to-do list

/___________________\
| [r] = removed
| [n] = not done    |
| [I] = in progress |
| [D] = done        |
\-------------------/

- tab based interface [D]
- cryptii pipe tab [r]
- remake revolt+ [D]
- make the library work [I]