---
permalink: /beta
---
# The new thingy!
## No need for a shortcut anymore, just tap a link, share and add to home screen.
<br/>

- [DEFIANT store]()
- [REVOLT](./revolt.html)
- [MUTINY](./mutiny.html)
- [DISUNITY](./disunity.html)
- [MULTI](./multi.html)
- []()
- []()
- []()
- []()
- []()
- []()
- []()
- []()
<br/>
<br/>

### CRIMSON PWAs
CRIMSON is the wicked and corrupted department of DefiantDev. They deal with things like "How could we cause a literal revolt within the REVOLT PWA?".<br/>
And that's what they've done. <br/>
They are also masters of CSS. The pretty comes at a cost of participating in the corruption of this world. In my opinion, it's worth it.
- [CRIMSON (REVOLT+)](../crimson/revolt+.html)
<br/>
<br/>

### Legacy PWAs
- [old DEFIANT store](./olddefiantstore.html)