---
permalink: /collections
---
# Collections
<br/>

![ANARCHY collection](../graphics/anarchy.png)
[⬛](./anarchy.md)<br/>
The main PWAs of the DEFIANT OS.
- They have a fully custom icon
- We work on these more often than the others
<br/>
<br/>
<br/>

![HUE collection](../graphics/hue.png)
[⬛](./hue.md)<br/>
The quote unquote side projects.
- They have a hue modified icon
- We work on these a bit less
<br/>
<br/>
<br/>

![ALIEN GARDEN collection](../graphics/alien.png)
[⬛](./alien.md)<br/>
Suggestions we've taken from our subreddit, [r/defiantdev](https://reddit.com/r/defiantdev).
- You suggest the contents
- You suggest the icon
- We make it a reality